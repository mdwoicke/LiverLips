<#
.SYNOPSIS
    Build-RiskBeacon.ps1 - Builds a valid .msapp from source using Power Platform CLI
    
.DESCRIPTION
    This script:
    1. Checks for (and optionally installs) Power Platform CLI
    2. Extracts the embedded source files to a temp directory
    3. Runs 'pac canvas pack' to produce a valid .msapp
    4. Places the .msapp on your Desktop ready to import
    
.USAGE
    Right-click > Run with PowerShell
    -or-
    .\Build-RiskBeacon.ps1
    
.NOTES
    Author: Digital Response Technologies, LLC
    Requires: Windows 10/11, PowerShell 5.1+
#>

$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "Risk Beacon IRM - Build Tool"

# ============================================================
# CONFIG
# ============================================================
$AppName = "risk-beacon"
$OutputDir = [Environment]::GetFolderPath("Desktop")
$OutputMsapp = Join-Path $OutputDir "$AppName.msapp"
$TempRoot = Join-Path $env:TEMP "risk-beacon-build-$(Get-Random)"
$SourceDir = Join-Path $TempRoot "sourcecode"

# ============================================================
# BANNER
# ============================================================
Write-Host ""
Write-Host "  ================================================" -ForegroundColor Red
Write-Host "  |   Risk Beacon IRM - .msapp Build Tool        |" -ForegroundColor Red
Write-Host "  |   Digital Response Technologies, LLC         |" -ForegroundColor Red
Write-Host "  ================================================" -ForegroundColor Red
Write-Host ""

# ============================================================
# STEP 1: Check for Power Platform CLI
# ============================================================
Write-Host "[1/4] Checking for Power Platform CLI..." -ForegroundColor Cyan

$pac = Get-Command pac -ErrorAction SilentlyContinue
if (-not $pac) {
    Write-Host "  Power Platform CLI not found." -ForegroundColor Yellow
    Write-Host ""
    $install = Read-Host "  Install it now via winget? (Y/n)"
    if ($install -ne 'n') {
        Write-Host "  Installing Microsoft.PowerPlatformCLI..." -ForegroundColor Yellow
        winget install Microsoft.PowerPlatformCLI --accept-package-agreements --accept-source-agreements
        
        # Refresh PATH
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        $pac = Get-Command pac -ErrorAction SilentlyContinue
        if (-not $pac) {
            Write-Host ""
            Write-Host "  ERROR: pac still not found after install." -ForegroundColor Red
            Write-Host "  Please close this window, open a NEW PowerShell, and run this script again." -ForegroundColor Yellow
            Write-Host "  (The PATH update requires a new terminal session)" -ForegroundColor Yellow
            Read-Host "Press Enter to exit"
            exit 1
        }
    }
    else {
        Write-Host ""
        Write-Host "  Cannot build .msapp without Power Platform CLI." -ForegroundColor Red
        Write-Host "  Install manually: winget install Microsoft.PowerPlatformCLI" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
}

$pacVersion = & pac --version 2>&1
Write-Host "  Found: pac $pacVersion" -ForegroundColor Green

# ============================================================
# STEP 2: Extract embedded source files
# ============================================================
Write-Host ""
Write-Host "[2/4] Extracting source files..." -ForegroundColor Cyan

New-Item -ItemType Directory -Path $SourceDir -Force | Out-Null
New-Item -ItemType Directory -Path "$SourceDir\Src" -Force | Out-Null
New-Item -ItemType Directory -Path "$SourceDir\DataSources" -Force | Out-Null
New-Item -ItemType Directory -Path "$SourceDir\Connections" -Force | Out-Null
New-Item -ItemType Directory -Path "$SourceDir\Entropy" -Force | Out-Null
New-Item -ItemType Directory -Path "$SourceDir\Assets" -Force | Out-Null
New-Item -ItemType Directory -Path "$SourceDir\pkgs\TableDefinitions" -Force | Out-Null

# --- Helper to write embedded content ---
function Write-SourceFile {
    param([string]$RelPath, [string]$Content)
    $fullPath = Join-Path $SourceDir $RelPath
    $dir = Split-Path $fullPath -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    [System.IO.File]::WriteAllText($fullPath, $Content, [System.Text.UTF8Encoding]::new($false))
    Write-Host "  + $RelPath" -ForegroundColor Gray
}

# --- CanvasManifest.json ---
Write-SourceFile "CanvasManifest.json" @'
{
  "FormatVersion": 2,
  "Properties": {
    "Name": "Risk Beacon - IRM Operating Model",
    "Description": "Integrated Risk Management app for cyber risk tracking",
    "Author": "Digital Response Technologies, LLC",
    "FileID": "risk-beacon-irm-v1",
    "AppVersion": "1.0.0",
    "PowerAppsRelease": "3.24000",
    "PublishTarget": "player"
  },
  "PublishInfo": {
    "AppName": "Risk Beacon",
    "PublishState": "Published",
    "Logo": ""
  },
  "ScreenOrder": [
    "scrFMA",
    "scrIssueDetails",
    "scrIssueMonitoring"
  ]
}
'@

# --- ComponentReferences.json ---
Write-SourceFile "ComponentReferences.json" "[]"

# --- Connections.json ---
Write-SourceFile "Connections\Connections.json" @'
{
  "SharePoint": {
    "id": "/providers/Microsoft.PowerApps/apis/shared_sharepointonline",
    "connectionRef": {
      "id": "/providers/Microsoft.PowerApps/apis/shared_sharepointonline"
    }
  }
}
'@

# --- DataSources ---
Write-SourceFile "DataSources\CyberRiskIssues.json" @'
{
  "CyberRiskIssues": {
    "Type": "ServiceProvider",
    "Name": "CyberRiskIssues",
    "DatasetName": "SharePoint",
    "ServiceProviderName": "SharePointOnline",
    "Schema": {
      "IssueNumber": { "Type": "String" },
      "IssuePhase": { "Type": "Choice" },
      "L2BusinessName": { "Type": "Choice" },
      "Domain": { "Type": "String" },
      "PrimaryTheme": { "Type": "Choice" },
      "PromptTitle": { "Type": "String" },
      "IssueAsOfDate": { "Type": "Date" }
    }
  }
}
'@

Write-SourceFile "DataSources\FailureModes.json" @'
{
  "FailureModes": {
    "Type": "ServiceProvider",
    "Name": "FailureModes",
    "DatasetName": "SharePoint",
    "ServiceProviderName": "SharePointOnline",
    "Schema": {
      "FailureMode": { "Type": "String" },
      "PrimaryProcess": { "Type": "String" },
      "AvgSeverity": { "Type": "Number" },
      "IssueCount": { "Type": "Number" },
      "CompositeScore": { "Type": "Number" },
      "Status": { "Type": "Choice" },
      "Owner": { "Type": "String" },
      "Theme": { "Type": "Choice" }
    }
  }
}
'@

# --- Entropy ---
Write-SourceFile "Entropy\entropy.json" @'
{
  "VolatileProperties": {
    "LocalConnectionReferences": {}
  }
}
'@

# --- Assets ---
Write-SourceFile "Assets\resources.json" '{ "Resources": [] }'

# --- pkgs ---
Write-SourceFile "pkgs\TableDefinitions\.gitkeep" ""

# --- Themes.json ---
Write-SourceFile "Src\Themes.json" @'
{
  "CurrentTheme": "RiskBeaconTheme",
  "CustomThemes": {
    "RiskBeaconTheme": {
      "name": "RiskBeaconTheme",
      "palette": {
        "themePrimary": "#D32F2F",
        "themeLighterAlt": "#FEF5F5",
        "themeLighter": "#FCDADA",
        "themeLight": "#F9B9B9",
        "themeTertiary": "#F37676",
        "themeSecondary": "#ED3B3B",
        "themeDarkAlt": "#BE2A2A",
        "themeDark": "#A12323",
        "themeDarker": "#771A1A",
        "neutralLighterAlt": "#F8F8F8",
        "neutralLighter": "#F4F4F4",
        "neutralLight": "#EAEAEA",
        "neutralQuaternaryAlt": "#DADADA",
        "neutralQuaternary": "#D0D0D0",
        "neutralTertiaryAlt": "#C8C8C8",
        "neutralTertiary": "#595959",
        "neutralSecondary": "#373737",
        "neutralPrimaryAlt": "#2F2F2F",
        "neutralPrimary": "#212121",
        "neutralDark": "#151515",
        "black": "#0B0B0B",
        "white": "#FFFFFF"
      }
    }
  }
}
'@

# ============================================================
# STEP 2b: Write .pa.yaml source files
# ============================================================
# These are written from the script directory's src\ folder if available,
# otherwise from embedded content below.

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoSrcDir = Join-Path $scriptDir "..\src"

$yamlFiles = @("App.pa.yaml", "scrFMA.pa.yaml", "scrIssueDetails.pa.yaml", "scrIssueMonitoring.pa.yaml")

foreach ($yf in $yamlFiles) {
    $repoFile = Join-Path $repoSrcDir $yf
    $destFile = Join-Path "$SourceDir\Src" $yf
    
    if (Test-Path $repoFile) {
        Copy-Item $repoFile $destFile -Force
        Write-Host "  + Src\$yf (from repo)" -ForegroundColor Gray
    }
    else {
        Write-Host "  ! Src\$yf not found in repo src\ folder" -ForegroundColor Yellow
        Write-Host "    Looking in current directory..." -ForegroundColor Yellow
        
        $localFile = Join-Path $scriptDir $yf
        if (Test-Path $localFile) {
            Copy-Item $localFile $destFile -Force
            Write-Host "  + Src\$yf (from local)" -ForegroundColor Gray
        }
        else {
            Write-Host "  ERROR: Cannot find $yf" -ForegroundColor Red
            Write-Host "  Place the .pa.yaml files in the src\ folder next to this script." -ForegroundColor Yellow
            Read-Host "Press Enter to exit"
            exit 1
        }
    }
}

Write-Host "  Source files extracted to: $SourceDir" -ForegroundColor Green

# ============================================================
# STEP 3: Pack with pac canvas pack
# ============================================================
Write-Host ""
Write-Host "[3/4] Building .msapp with Power Platform CLI..." -ForegroundColor Cyan

$packOutput = Join-Path $TempRoot "$AppName.msapp"

try {
    $result = & pac canvas pack --sources $SourceDir --msapp $packOutput 2>&1
    $exitCode = $LASTEXITCODE
    
    # Show output
    $result | ForEach-Object { Write-Host "  $_" -ForegroundColor Gray }
    
    if ($exitCode -ne 0 -and -not (Test-Path $packOutput)) {
        Write-Host ""
        Write-Host "  WARNING: pac canvas pack returned exit code $exitCode" -ForegroundColor Yellow
        Write-Host "  This may be a checksum warning (common and usually safe)." -ForegroundColor Yellow
    }
    
    if (Test-Path $packOutput) {
        Write-Host "  Pack succeeded!" -ForegroundColor Green
    }
    else {
        throw "Output file not created"
    }
}
catch {
    Write-Host ""
    Write-Host "  ERROR: pac canvas pack failed." -ForegroundColor Red
    Write-Host "  Error: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Source files are preserved at:" -ForegroundColor Yellow
    Write-Host "  $SourceDir" -ForegroundColor White
    Write-Host ""
    Write-Host "  Try manually:" -ForegroundColor Yellow
    Write-Host "  pac canvas pack --sources `"$SourceDir`" --msapp `"$OutputMsapp`"" -ForegroundColor Cyan
    Read-Host "Press Enter to exit"
    exit 1
}

# ============================================================
# STEP 4: Copy to Desktop
# ============================================================
Write-Host ""
Write-Host "[4/4] Copying to Desktop..." -ForegroundColor Cyan

Copy-Item $packOutput $OutputMsapp -Force
$fileSize = [math]::Round((Get-Item $OutputMsapp).Length / 1KB, 1)
Write-Host "  Saved: $OutputMsapp ($fileSize KB)" -ForegroundColor Green

# Cleanup temp
Remove-Item $TempRoot -Recurse -Force -ErrorAction SilentlyContinue

# ============================================================
# DONE
# ============================================================
Write-Host ""
Write-Host "  ================================================" -ForegroundColor Green
Write-Host "  |   BUILD COMPLETE                              |" -ForegroundColor Green
Write-Host "  |                                               |" -ForegroundColor Green
Write-Host "  |   File: $AppName.msapp" -ForegroundColor Green
Write-Host "  |   Location: Desktop                           |" -ForegroundColor Green
Write-Host "  |   Size: $fileSize KB" -ForegroundColor Green
Write-Host "  |                                               |" -ForegroundColor Green
Write-Host "  |   Next Steps:                                 |" -ForegroundColor Green
Write-Host "  |   1. Go to make.powerapps.com                 |" -ForegroundColor Green
Write-Host "  |   2. Apps > Import canvas app                 |" -ForegroundColor Green
Write-Host "  |   3. Browse to Desktop > $AppName.msapp" -ForegroundColor Green
Write-Host "  |   4. Upload > Import                          |" -ForegroundColor Green
Write-Host "  ================================================" -ForegroundColor Green
Write-Host ""

$open = Read-Host "Open make.powerapps.com now? (Y/n)"
if ($open -ne 'n') {
    Start-Process "https://make.powerapps.com"
}

Read-Host "Press Enter to exit"
