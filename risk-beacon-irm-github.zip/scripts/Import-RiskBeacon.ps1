# ============================================================
# Risk Beacon IRM - Power Apps Import Helper
# ============================================================
# This script helps you import risk-beacon.msapp into Power Apps.
#
# METHOD 1 (Recommended - Direct Open):
#   1. Go to https://make.powerapps.com
#   2. Click "Apps" in left nav > "Import canvas app"
#   3. Browse to: risk-beacon.msapp
#   4. Click "Upload" then "Import"
#
# METHOD 2 (Power Apps Studio):
#   1. Open any existing app in Power Apps Studio
#   2. File > Open > Browse
#   3. Select risk-beacon.msapp
#
# METHOD 3 (CLI - if you have Power Platform CLI):
#   Run this script with: .\Import-RiskBeacon.ps1 -UseCLI
# ============================================================

param(
    [switch]$UseCLI,
    [switch]$Verify
)

$msappFile = Join-Path $PSScriptRoot "risk-beacon.msapp"

if (-not (Test-Path $msappFile)) {
    Write-Host "ERROR: risk-beacon.msapp not found in script directory." -ForegroundColor Red
    Write-Host "Make sure risk-beacon.msapp is in the same folder as this script." -ForegroundColor Yellow
    exit 1
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Risk Beacon IRM - Power Apps Import Tool" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

if ($Verify) {
    Write-Host "Verifying .msapp file contents..." -ForegroundColor Yellow
    Write-Host ""
    
    # Rename to .zip, list contents, rename back
    $zipCopy = "$msappFile.verify.zip"
    Copy-Item $msappFile $zipCopy
    
    try {
        $shell = New-Object -ComObject Shell.Application
        $zip = $shell.Namespace((Resolve-Path $zipCopy).Path)
        
        Write-Host "Archive contents:" -ForegroundColor Green
        foreach ($item in $zip.Items()) {
            Write-Host "  $($item.Name)" -ForegroundColor White
        }
        
        Write-Host ""
        Write-Host "File size: $([math]::Round((Get-Item $msappFile).Length / 1KB, 1)) KB" -ForegroundColor Green
        Write-Host "File is a valid ZIP archive." -ForegroundColor Green
    }
    catch {
        Write-Host "Could not read archive: $_" -ForegroundColor Red
    }
    finally {
        Remove-Item $zipCopy -Force -ErrorAction SilentlyContinue
    }
    
    Write-Host ""
    exit 0
}

if ($UseCLI) {
    # Check for pac CLI
    $pacPath = Get-Command pac -ErrorAction SilentlyContinue
    if (-not $pacPath) {
        Write-Host "Power Platform CLI (pac) not found." -ForegroundColor Red
        Write-Host ""
        Write-Host "Install it with:" -ForegroundColor Yellow
        Write-Host "  winget install Microsoft.PowerPlatformCLI" -ForegroundColor White
        Write-Host ""
        Write-Host "Then re-run this script." -ForegroundColor Yellow
        exit 1
    }
    
    Write-Host "Power Platform CLI found at: $($pacPath.Source)" -ForegroundColor Green
    Write-Host ""
    Write-Host "Authenticating..." -ForegroundColor Yellow
    pac auth create
    
    Write-Host ""
    Write-Host "To import directly, open Power Apps Studio and use File > Open > Browse" -ForegroundColor Cyan
    Write-Host "Select: $msappFile" -ForegroundColor White
}
else {
    Write-Host "Your .msapp file is ready:" -ForegroundColor Green
    Write-Host "  $msappFile" -ForegroundColor White
    Write-Host ""
    Write-Host "--- IMPORT OPTIONS ---" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Option A: make.powerapps.com (Recommended)" -ForegroundColor Yellow
    Write-Host "  1. Go to https://make.powerapps.com" -ForegroundColor White
    Write-Host "  2. Click 'Apps' > 'Import canvas app'" -ForegroundColor White
    Write-Host "  3. Browse to and select: risk-beacon.msapp" -ForegroundColor White
    Write-Host "  4. Click Upload, then Import" -ForegroundColor White
    Write-Host ""
    Write-Host "Option B: Power Apps Studio" -ForegroundColor Yellow
    Write-Host "  1. Open any app in Power Apps Studio" -ForegroundColor White
    Write-Host "  2. File > Open > Browse" -ForegroundColor White
    Write-Host "  3. Select risk-beacon.msapp" -ForegroundColor White
    Write-Host ""
    Write-Host "Option C: CLI Import" -ForegroundColor Yellow
    Write-Host "  Run: .\Import-RiskBeacon.ps1 -UseCLI" -ForegroundColor White
    Write-Host ""
    
    # Offer to open make.powerapps.com
    $open = Read-Host "Open make.powerapps.com now? (y/n)"
    if ($open -eq 'y') {
        Start-Process "https://make.powerapps.com"
    }
}

Write-Host ""
Write-Host "Done!" -ForegroundColor Green
