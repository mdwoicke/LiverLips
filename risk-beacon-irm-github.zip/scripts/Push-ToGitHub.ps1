# ============================================================
# Push Risk Beacon IRM to GitHub
# ============================================================
# Usage:
#   .\Push-ToGitHub.ps1 -RepoName "risk-beacon-irm"
#   .\Push-ToGitHub.ps1 -RepoName "risk-beacon-irm" -OrgName "your-org"
# ============================================================

param(
    [Parameter(Mandatory=$true)]
    [string]$RepoName = "risk-beacon-irm",
    
    [string]$OrgName = "",
    
    [string]$Description = "Power Apps Canvas App for Integrated Risk Management - Cyber risk tracking with FMA, Issue Details, and Monitoring dashboards",
    
    [switch]$Private
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Risk Beacon IRM - GitHub Push Script" -ForegroundColor Cyan  
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# Check for git
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: git is not installed." -ForegroundColor Red
    Write-Host "Install from: https://git-scm.com/download/win" -ForegroundColor Yellow
    exit 1
}

# Check for GitHub CLI
$hasGhCli = Get-Command gh -ErrorAction SilentlyContinue

# Initialize git repo
Write-Host "Initializing git repository..." -ForegroundColor Yellow
git init
git add -A
git commit -m "Initial commit: Risk Beacon IRM Power App

- 3 screens: FMA, Issue Details, Issue Monitoring
- Power Apps YAML source code (.pa.yaml)
- Pre-built .msapp for direct import
- Standalone HTML prototype
- Sample data (48 records)
- SharePoint list schemas and deployment guide"

# Create GitHub repo and push
if ($hasGhCli) {
    Write-Host ""
    Write-Host "GitHub CLI detected. Creating repository..." -ForegroundColor Green
    
    $visibility = if ($Private) { "--private" } else { "--public" }
    $owner = if ($OrgName) { "--owner $OrgName" } else { "" }
    
    $cmd = "gh repo create $RepoName $visibility --description `"$Description`" --source . --push $owner"
    Write-Host "Running: $cmd" -ForegroundColor Gray
    Invoke-Expression $cmd
    
    Write-Host ""
    Write-Host "Done! Your repo is live." -ForegroundColor Green
    
    if ($OrgName) {
        Write-Host "URL: https://github.com/$OrgName/$RepoName" -ForegroundColor Cyan
    } else {
        $username = gh api user --jq '.login'
        Write-Host "URL: https://github.com/$username/$RepoName" -ForegroundColor Cyan
    }
}
else {
    Write-Host ""
    Write-Host "GitHub CLI (gh) not found. Manual steps:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "1. Create a new repo at: https://github.com/new" -ForegroundColor White
    Write-Host "   Name: $RepoName" -ForegroundColor White
    Write-Host ""
    Write-Host "2. Then run these commands:" -ForegroundColor White
    Write-Host ""
    
    if ($OrgName) {
        Write-Host "   git remote add origin https://github.com/$OrgName/$RepoName.git" -ForegroundColor Cyan
    } else {
        Write-Host "   git remote add origin https://github.com/YOUR-USERNAME/$RepoName.git" -ForegroundColor Cyan
    }
    
    Write-Host "   git branch -M main" -ForegroundColor Cyan
    Write-Host "   git push -u origin main" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Or install GitHub CLI for one-command setup:" -ForegroundColor Yellow
    Write-Host "   winget install GitHub.cli" -ForegroundColor Cyan
}

Write-Host ""
