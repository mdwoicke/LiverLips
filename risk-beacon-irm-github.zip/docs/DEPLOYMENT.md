# Risk Beacon IRM — Deployment Guide

## Prerequisites

- Microsoft 365 E3/E5 or Power Apps per-user license
- Power Apps Maker role in your environment
- SharePoint site with permissions to create lists
- (Optional) Power Platform CLI: `winget install Microsoft.PowerPlatformCLI`

## Method 1: Direct .msapp Import

1. Download `risk-beacon.msapp` from the repo root
2. Navigate to [make.powerapps.com](https://make.powerapps.com)
3. Click **Apps** in the left navigation
4. Click **Import canvas app** in the command bar
5. Click **Upload**, browse to `risk-beacon.msapp`
6. Click **Import**
7. Once imported, click on the app to open in Power Apps Studio
8. Connect your SharePoint data sources (see below)
9. Save and Publish

## Method 2: Build from Source

```powershell
# Clone the repository
git clone https://github.com/YOUR-ORG/risk-beacon-irm.git
cd risk-beacon-irm

# Pack the source files into an .msapp
pac canvas pack --sources .\src --msapp .\risk-beacon-built.msapp

# Open in Power Apps Studio
# File > Open > Browse > select risk-beacon-built.msapp
```

## Setting Up SharePoint Data Sources

### Step 1: Create the CyberRiskIssues List

On your SharePoint site, create a new list called `CyberRiskIssues` with these columns:

| Column Name | Type | Configuration |
|-------------|------|---------------|
| IssueNumber | Single line of text | Required |
| IssuePhase | Choice | Open, Plan, Mitigate & Monitor, Closed |
| L2BusinessName | Choice | CSBB, Chief Technology Office, CL |
| Domain | Single line of text | |
| PrimaryTheme | Choice | Security Monitoring, Data Management, Access Management, Cyber Incident Management |
| PromptTitle | Single line of text | |
| IssueAsOfDate | Date | |

### Step 2: Create the FailureModes List

Create a second list called `FailureModes` with these columns:

| Column Name | Type | Configuration |
|-------------|------|---------------|
| FailureMode | Multiple lines of text | |
| PrimaryProcess | Single line of text | |
| AvgSeverity | Number | 0 decimal places, min 0, max 10 |
| IssueCount | Number | 0 decimal places |
| CompositeScore | Number | 0 decimal places |
| Status | Choice | In Progress, Mitigation Required, Analysis, Scheduled Drill Q4, Reviewing |
| Owner | Single line of text | |
| Theme | Choice | Security Monitoring, Data Management, Access Management, Cyber Incident Management |

### Step 3: Import Sample Data

Import `data/sample_data.csv` into your SharePoint lists using:
- SharePoint Quick Edit view (paste from Excel)
- Power Automate flow
- PnP PowerShell: `Import-PnPListItems`

### Step 4: Connect the App

1. Open the app in Power Apps Studio
2. Go to **Data** panel (cylinder icon) → **Add data**
3. Select **SharePoint** → enter your site URL
4. Select both `CyberRiskIssues` and `FailureModes` lists
5. In `App.OnStart`, remove the `ClearCollect(colFailureModes, ...)` block
6. Update gallery `Items` properties to reference your SharePoint lists directly
7. **Save** and **Publish**

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "The data source is not valid" | Reconnect SharePoint in the Data panel |
| Blank screen after import | Check that `App.OnStart` runs without errors |
| Missing columns in gallery | Verify SharePoint list column names match exactly |
| Checksum warning on import | Re-pack from source using `pac canvas pack` |
| CLI not recognized | Run `winget install Microsoft.PowerPlatformCLI` and restart terminal |

## Color Reference

| Color | Hex | RGB | Usage |
|-------|-----|-----|-------|
| Primary Red | #D32F2F | RGBA(211, 47, 47, 1) | Headers, active nav, high scores |
| Dark Red | #B71C1C | RGBA(183, 28, 28, 1) | Gradient accents |
| Score Orange | #E65100 | RGBA(230, 81, 0, 1) | Medium scores, Mitigate phase |
| Score Amber | #F9A825 | RGBA(249, 168, 37, 1) | Low scores |
| Phase Blue | #1565C0 | RGBA(21, 101, 192, 1) | Plan phase, links |
| Phase Green | #2E7D32 | RGBA(46, 125, 50, 1) | Closed, In Progress |
| Background | #F5F5F5 | RGBA(245, 245, 245, 1) | Screen fill |
| Border | #E0E0E0 | RGBA(224, 224, 224, 1) | Cards, tables |
