# 🛡️ Risk Beacon — IRM Operating Model

> A Power Apps Canvas App for Integrated Risk Management (IRM) — tracking cyber risk failure modes, issue details, and monitoring dashboards.

![Power Apps](https://img.shields.io/badge/Power%20Apps-Canvas-742774?logo=powerapps&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green)
![Platform](https://img.shields.io/badge/Platform-Microsoft%20365-blue?logo=microsoft)
![Status](https://img.shields.io/badge/Status-Ready%20to%20Deploy-brightgreen)

---

## 📋 Overview

Risk Beacon is a Power Apps Canvas App designed for enterprise cyber risk management teams. It provides three integrated dashboards for tracking failure modes, issue lifecycle, and real-time monitoring of risk metrics.

**Key Features:**
- **FMA Dashboard** — Failure Mode Analysis with composite risk scoring, sortable tables, and color-coded severity bars
- **Issue Details** — Searchable issue registry with phase/business/theme filtering and phase-coded badges
- **Issue Monitoring** — KPI cards, business unit distribution charts, and theme breakdown visualizations

---

## 🖥️ Screenshots

The app features a Wells Fargo-branded red/white design with three navigable tabs:

| FMA Screen | Issue Details | Issue Monitoring |
|:---:|:---:|:---:|
| Composite risk scores with gradient bars | Filterable issue registry | KPI cards + bar charts |

---

## 🚀 Quick Start

### Option A: One-Click Build Script (Recommended)

The `.msapp` must be built using Microsoft's Power Platform CLI to pass integrity checks. We've included a script that does everything automatically:

```powershell
# Clone this repo
git clone https://github.com/YOUR-ORG/risk-beacon-irm.git
cd risk-beacon-irm

# Run the build script (installs CLI if needed, packs .msapp, places on Desktop)
.\scripts\Build-RiskBeacon.ps1
```

The script will:
1. Check for (and optionally install) Power Platform CLI
2. Extract all source files to a temp directory  
3. Run `pac canvas pack` to produce a **valid, signed .msapp**
4. Place the `.msapp` on your Desktop ready to import

Then: **make.powerapps.com** → **Apps** → **Import canvas app** → select the `.msapp`

### Option B: Manual Build with Power Platform CLI

```powershell
# Install CLI (one-time)
winget install Microsoft.PowerPlatformCLI

# Clone and pack
git clone https://github.com/YOUR-ORG/risk-beacon-irm.git
cd risk-beacon-irm
pac canvas pack --sources .\src --msapp .\risk-beacon.msapp

# Import: make.powerapps.com > Apps > Import canvas app > Browse > risk-beacon.msapp
```

### Option C: Live HTML Preview (No Power Apps Required)

Double-click `RiskBeacon_Standalone.html` to run the full app prototype in any browser — zero dependencies, fully self-contained.

> **Note:** A valid `.msapp` can only be built using Microsoft's Power Platform CLI, which adds required internal checksums. The build script (Option A) handles this automatically.

---

## 📁 Repository Structure

```
risk-beacon-irm/
├── RiskBeacon_Standalone.html     # Self-contained HTML/React prototype (double-click to run)
├── src/                           # Power Apps source code (.pa.yaml)
│   ├── App.pa.yaml                # App-level config, OnStart, theme, sample data
│   ├── scrFMA.pa.yaml             # Failure Mode Analysis screen
│   ├── scrIssueDetails.pa.yaml    # Issue Details screen with filters
│   ├── scrIssueMonitoring.pa.yaml # Monitoring dashboard with KPIs
│   ├── Themes.json                # Custom RiskBeaconTheme palette
│   ├── CanvasManifest.json        # App manifest and screen order
│   ├── CyberRiskIssues.json       # Data source schema
│   ├── FailureModes.json          # Data source schema
│   ├── Connections.json            # SharePoint connection reference
│   ├── ComponentReferences.json    # External component refs
│   └── entropy.json                # Volatile properties
├── data/
│   └── sample_data.csv            # 48 sample records for SharePoint import
├── scripts/
│   ├── Build-RiskBeacon.ps1       # One-click build script (installs CLI + packs .msapp)
│   ├── Import-RiskBeacon.ps1      # PowerShell import helper
│   └── Push-ToGitHub.ps1          # Push repo to GitHub
└── docs/
    └── DEPLOYMENT.md              # Detailed deployment guide
```

---

## 🗄️ Data Architecture

The app connects to two SharePoint lists:

### CyberRiskIssues (7 columns)

| Column | Type | Values |
|--------|------|--------|
| IssueNumber | Single line of text | e.g., "CRI-2024-001" |
| IssuePhase | Choice | Open, Plan, Mitigate & Monitor, Closed |
| L2BusinessName | Choice | CSBB, Chief Technology Office, CL |
| Domain | Single line of text | e.g., "Infrastructure Security" |
| PrimaryTheme | Choice | Security Monitoring, Data Management, Access Management, Cyber Incident Management |
| PromptTitle | Single line of text | Issue description |
| IssueAsOfDate | Date | Date of last update |

### FailureModes (8 columns)

| Column | Type | Description |
|--------|------|-------------|
| FailureMode | Multiple lines of text | Failure mode description |
| PrimaryProcess | Single line of text | Associated process |
| AvgSeverity | Number (0-10) | Average severity rating |
| IssueCount | Number | Count of related issues |
| CompositeScore | Number | Calculated composite score |
| Status | Choice | In Progress, Mitigation Required, Analysis, Scheduled Drill Q4, Reviewing |
| Owner | Single line of text | Assigned owner |
| Theme | Choice | Risk theme category |

### Sample Data Import

Import `data/sample_data.csv` into your SharePoint lists to get started with 48 pre-configured records.

---

## 🎨 Design Specification

### Color Palette

| Token | Hex | Usage |
|-------|-----|-------|
| Primary Red | `#D32F2F` | Header, footer, active nav, high scores (≥65) |
| Dark Red | `#B71C1C` | Gradients, borders |
| Score Orange | `#E65100` | Medium scores (50-64), Mitigate phase |
| Score Amber | `#F9A825` | Low scores (<50) |
| Phase Blue | `#1565C0` | Plan phase, links |
| Phase Green | `#2E7D32` | Closed phase, In Progress status |
| Background | `#F5F5F5` | App background |
| Border Gray | `#E0E0E0` | Card and table borders |

### Key Formulas

**Composite Score Bar Color:**
```
If(CompositeScore >= 65, RGBA(211,47,47,1),
   CompositeScore >= 50, RGBA(230,81,0,1),
   RGBA(249,168,37,1))
```

**Score Bar Width (proportional):**
```
110 * (CompositeScore / 80)
```

**Issue Filter (multi-condition):**
```
Filter(CyberRiskIssues,
    (varFilterPhase = "All" || IssuePhase = varFilterPhase) &&
    (varFilterBusiness = "All" || L2BusinessName = varFilterBusiness) &&
    (varFilterTheme = "All" || PrimaryTheme = varFilterTheme) &&
    (varSearchText = "" || StartsWith(IssueNumber, varSearchText))
)
```

---

## 📋 Prerequisites

| Requirement | Details |
|-------------|---------|
| Microsoft 365 License | E3/E5 or Power Apps per-user plan |
| Power Apps Maker Role | Environment Maker or System Customizer |
| SharePoint Site | For CyberRiskIssues and FailureModes lists |
| Power Platform CLI | Optional — for building from source |

---

## 🔧 Customization

### Connecting to Your SharePoint

1. Open the app in Power Apps Studio
2. Go to **Data** panel → **Add data** → **SharePoint**
3. Enter your SharePoint site URL
4. Select `CyberRiskIssues` and `FailureModes` lists
5. Remove the sample `ClearCollect` from `App.OnStart` and replace with your live data source references

### Changing the Theme

Edit `src/Themes.json` to customize the color palette, or modify the `Theme` property in `src/App.pa.yaml`.

---

## 🤝 Contributing

1. Fork this repository
2. Create a feature branch: `git checkout -b feature/my-enhancement`
3. Edit `.pa.yaml` files in `src/`
4. Test by packing: `pac canvas pack --sources .\src --msapp .\test.msapp`
5. Open a Pull Request

---

## 📄 License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.

---

## 🙏 Acknowledgments

- Built with [Microsoft Power Apps](https://powerapps.microsoft.com)
- Source format follows the [PnP Power Apps Samples](https://github.com/pnp/powerapps-samples) convention
- Developed by [Digital Response Technologies, LLC](https://github.com/YOUR-ORG)

---

> **Disclaimer:** This is a sample/template application. Modify data sources, branding, and security settings before deploying to production environments.
